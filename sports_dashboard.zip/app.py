import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

st.set_page_config(page_title="Sports Data Dashboard", layout="wide")
st.title("🎾 Sports Competitions & Complexes Dashboard")

# Load CSVs
comp_file = "SQL Data for Competitions table Answers.csv"
complex_file = "SQL Data for Complexes table Answers.csv"

try:
    competitions_df = pd.read_csv(comp_file)
    complexes_df = pd.read_csv(complex_file)
except FileNotFoundError:
    st.error("❌ Please make sure both CSV files exist.")
    st.stop()

# Sidebar filters
st.sidebar.title("🔍 Filters")
selected_type = st.sidebar.multiselect("Competition Type", competitions_df["type"].dropna().unique())
selected_gender = st.sidebar.multiselect("Gender", competitions_df["gender"].dropna().unique())
selected_complex = st.sidebar.selectbox("Select a Complex", complexes_df["complex_name"].dropna().unique())

# Filter data
filtered_comp = competitions_df.copy()
if selected_type:
    filtered_comp = filtered_comp[filtered_comp["type"].isin(selected_type)]
if selected_gender:
    filtered_comp = filtered_comp[filtered_comp["gender"].isin(selected_gender)]

filtered_venues = complexes_df[complexes_df["complex_name"] == selected_complex]

# Show tables
st.subheader("📋 Competitions Table")
st.dataframe(filtered_comp, use_container_width=True)

st.subheader("📋 Venues for Selected Complex")
st.dataframe(filtered_venues, use_container_width=True)

# Visualizations
st.markdown("## 📊 Visualizations")
col1, col2 = st.columns(2)

with col1:
    st.markdown("### Competitions by Category")
    fig1, ax1 = plt.subplots()
    sns.countplot(data=filtered_comp, y="category_name", order=filtered_comp["category_name"].value_counts().index, ax=ax1)
    st.pyplot(fig1)

with col2:
    st.markdown("### Competitions by Type")
    fig2, ax2 = plt.subplots()
    sns.countplot(data=filtered_comp, x="type", palette="Set2", ax=ax2)
    st.pyplot(fig2)

col3, col4 = st.columns(2)

with col3:
    st.markdown("### Competitions by Gender")
    fig3, ax3 = plt.subplots()
    sns.countplot(data=filtered_comp, x="gender", palette="coolwarm", ax=ax3)
    st.pyplot(fig3)

with col4:
    st.markdown("### Venues per Complex")
    fig4, ax4 = plt.subplots()
    complexes_df["complex_name"].value_counts().plot(kind='barh', ax=ax4, color='mediumseagreen')
    st.pyplot(fig4)

st.markdown("### Venue Distribution Pie Chart")
fig5, ax5 = plt.subplots()
complexes_df["complex_name"].value_counts().plot.pie(autopct='%1.1f%%', ax=ax5)
ax5.set_ylabel("")
st.pyplot(fig5)
